from distutils.core import setup

setup(
	name		='nester',
	version		='1.0.0',
	py_modules	=['nester'],
	author		='whj',
	author_email	='whj0131@gmail.com',
	url		='www.baidu.com',
	description	='a simple example',
 )
